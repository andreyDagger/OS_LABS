bash mem.bash &
bash mem2.bash &
