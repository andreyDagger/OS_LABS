N=$((87000000/10/3))
K=$((30))
for ((i=1; i<=K; i++));
do
	bash newmem.bash $N &
	echo $!
done
